package medicode.harsh.com.medicode.Activitys.ACLS;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

import medicode.harsh.com.medicode.Adapters.ACLSAdapter;
import medicode.harsh.com.medicode.Models.ACLSList;
import medicode.harsh.com.medicode.R;

public class ACLS extends AppCompatActivity {

    RecyclerView recyclerView;
    ACLSAdapter adapter;
    private ArrayList<ACLSList> listContentArr = new ArrayList<ACLSList>();
    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acls);
        mContext= this;
        recyclerView=findViewById(R.id.recycleView_ACLS);
        LinearLayoutManager linearLayoutManager= new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        adapter= new ACLSAdapter(mContext,listContentArr);
        populateRecyclerViewValues();
        recyclerView.setAdapter(adapter);
    }
    private void populateRecyclerViewValues() {
        listContentArr.clear();
        ACLSList acls= new ACLSList();
        acls.setName("CARDIAC ARREST");
        listContentArr.add(acls);
        ACLSList acls1= new ACLSList();
        acls1.setName("DETAILS FOR CARDIAC ARREST");
        listContentArr.add(acls1);
        ACLSList acls2= new ACLSList();
        acls2.setName("IMMEDIATE POST-CARDIAC ARREST");
        listContentArr.add(acls2);
        ACLSList acls3= new ACLSList();
        acls3.setName("BRADYCARDIA WITH PULSE");
        listContentArr.add(acls3);
        ACLSList acls4= new ACLSList();
        acls4.setName("TACHYCARDIA WITH PULSE");
        listContentArr.add(acls4);
        adapter.notifyDataSetChanged();
    }
}
