package medicode.harsh.com.medicode.Activitys.ACLS;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.widget.ImageView;

import medicode.harsh.com.medicode.R;

public class ACLS_bracardia extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nrp);

        final ImageView iv_compressed = findViewById(R.id.zoom1);

        Task task = new Task(iv_compressed);
        task.execute();

//        Thread thread = new Thread(new Runnable() {
//            @Override
//            public void run() {
//                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.acls_bradycardia_en);
//
//                DisplayMetrics metrics = ACLS_bracardia.this.getResources().getDisplayMetrics();
//                int imageWidth = 0;
//                int imageHeight = 0;
//                if (bitmap != null) {
//                    imageWidth = bitmap.getWidth();
//                    imageHeight = bitmap.getHeight();
//                }
//
//                try {
//                    bitmap = Bitmap.createScaledBitmap(bitmap, metrics.widthPixels, metrics.heightPixels, true);
//                    BitmapFactory.Options options = new BitmapFactory.Options();
//                    options.inSampleSize = 2;
//                    final Bitmap finalBitmap = bitmap;
//                    runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            iv_compressed.setImageBitmap(finalBitmap);
//                        }
//                    });
//
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//        thread.start();

    }


    class  Task extends AsyncTask<Integer,Void,Bitmap>{

        ImageView imageView;
        public Task(ImageView imageView){
            this.imageView=imageView;
        }

        @Override
        protected Bitmap doInBackground(Integer... integers) {

            Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.acls_bradycardia_en);

            DisplayMetrics metrics = ACLS_bracardia.this.getResources().getDisplayMetrics();
            int imageWidth = 0;
            int imageHeight = 0;
            if (bitmap != null) {
                imageWidth = bitmap.getWidth();
                imageHeight = bitmap.getHeight();
            }
                bitmap = Bitmap.createScaledBitmap(bitmap, metrics.widthPixels, metrics.heightPixels, true);
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = 2;
                final Bitmap finalBitmap = bitmap;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        imageView.setImageBitmap(finalBitmap);
                    }
                });

                return null;

        }
    }
}
