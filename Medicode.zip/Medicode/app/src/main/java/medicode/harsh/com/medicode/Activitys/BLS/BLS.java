package medicode.harsh.com.medicode.Activitys.BLS;

import android.content.Context;

import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

import medicode.harsh.com.medicode.Adapters.AdpaterBLS;
import medicode.harsh.com.medicode.R;
import medicode.harsh.com.medicode.Models.blsList;

public class BLS extends AppCompatActivity {

    RecyclerView recyclerView;
    AdpaterBLS adapter1;
    private ArrayList<blsList> listContentArr = new ArrayList<blsList>();
    private Context mContext;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bls);

        recyclerView=findViewById(R.id.recycleView_BLS);
        LinearLayoutManager linearLayoutManager= new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        adapter1= new AdpaterBLS(mContext,listContentArr);
        populateRecyclerViewValues();adapter1.setListContent(listContentArr);
        recyclerView.setAdapter(adapter1);
    }



    private void populateRecyclerViewValues() {
        listContentArr.clear();
        blsList bls= new blsList();
        bls.setName("ADULT");
        listContentArr.add(bls);
        blsList bls1= new blsList();
        bls1.setName("PEDIATRIC");
        listContentArr.add(bls1);
        adapter1.notifyDataSetChanged();
    }
}
