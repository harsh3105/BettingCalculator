package medicode.harsh.com.medicode.Activitys.CPR;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

import medicode.harsh.com.medicode.Adapters.CPRAdapter;
import medicode.harsh.com.medicode.Models.CPRList;
import medicode.harsh.com.medicode.R;

public class CPR extends AppCompatActivity {

    RecyclerView recyclerView;
    CPRAdapter adapter;
    private ArrayList<CPRList> listContentArr = new ArrayList<CPRList>();
    private Context mContext;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cpr);
        mContext=this;
        recyclerView=findViewById(R.id.recycleView_CPR);
        LinearLayoutManager linearLayoutManager= new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        adapter= new CPRAdapter(mContext,listContentArr);
        populateRecyclerViewValues();
        recyclerView.setAdapter(adapter);
    }

    private void populateRecyclerViewValues() {
        listContentArr.clear();
        CPRList cpr= new CPRList();
        cpr.setName("ADULT BLS");
        listContentArr.add(cpr);
        CPRList cpr1= new CPRList();
        cpr1.setName("SIMPLE ADULT BLS");
        listContentArr.add(cpr1);
    }

}
