package medicode.harsh.com.medicode.Activitys.CPR;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.widget.ImageView;

import medicode.harsh.com.medicode.R;

public class CPR_simple extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nrp);

        final ImageView iv_compressed = findViewById(R.id.zoom1);
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.bls_simple_adult_cpr_en);

        DisplayMetrics metrics = this.getResources().getDisplayMetrics();
        int imageWidth = 0;
        int imageHeight = 0;
        if (bitmap != null) {
            imageWidth = bitmap.getWidth();
            imageHeight = bitmap.getHeight();
        }

        try {
            bitmap = Bitmap.createScaledBitmap(bitmap, metrics.widthPixels, metrics.heightPixels, true);
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 2;
            iv_compressed.setImageBitmap(bitmap);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
