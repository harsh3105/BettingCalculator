package medicode.harsh.com.medicode.Activitys.Header;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import medicode.harsh.com.medicode.Models.algoName;
import medicode.harsh.com.medicode.R;
import medicode.harsh.com.medicode.Adapters.rel;

public class algoritm extends Fragment {


    private View view;
    RecyclerView recyclerView;
    rel adapter1;
    private ArrayList<algoName> listContentArr = new ArrayList<>();
    private Context mContext;

    public algoritm() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.algoritm, container, false);
        mContext = getActivity();
        TextView txtGhost = view.findViewById(R.id.article);

        // Loading Font Face
        Typeface tf = Typeface.createFromAsset(getActivity().getAssets(),"GothamBook.ttf");

        // Applying font
        txtGhost.setTypeface(tf);


        recyclerView=view.findViewById(R.id.recycleView);
        LinearLayoutManager linearLayoutManager= new LinearLayoutManager(getActivity(),LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        adapter1=new rel(mContext);
        populateRecyclerViewValues();
        adapter1.setListContent(listContentArr);
        recyclerView.setAdapter(adapter1);

        return view;
    }
    private void populateRecyclerViewValues() {
        listContentArr.clear();
        algoName algo = new algoName();
        algo.setName("BLS");
        listContentArr.add(algo);
        algoName algo1 = new algoName();
        algo1.setName("ACLS");
        listContentArr.add(algo1);
        algoName algo2 = new algoName();
        algo2.setName("PALS");
        listContentArr.add(algo2);
        algoName algo3 = new algoName();
        algo3.setName("CPR");
        listContentArr.add(algo3);
        algoName algo4 = new algoName();
        algo4.setName("NRP");
        listContentArr.add(algo4);

    }

    }



