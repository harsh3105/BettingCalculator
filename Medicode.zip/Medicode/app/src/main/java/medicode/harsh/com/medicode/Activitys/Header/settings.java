package medicode.harsh.com.medicode.Activitys.Header;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.facebook.login.widget.ProfilePictureView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

import medicode.harsh.com.medicode.DataStore.SharePrefranceData;
import medicode.harsh.com.medicode.R;

public class settings extends Fragment {

    View view;
    Context mContext;

    private LoginButton loginButton;
    public EditText fName, lName, email;
    public Button button;
    private CallbackManager callbackManager;
    private static final String EMAIL = "email";
    private static final String Name = "name";
    private Button fbook;


    public settings() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mContext = getActivity();
        view = inflater.inflate(R.layout.settings, container, false);
        fName = view.findViewById(R.id.fname);
        lName = view.findViewById(R.id.lname);
        email = view.findViewById(R.id.email);
        button = view.findViewById(R.id.save);
        loginButton = view.findViewById(R.id.fb);
        fbook = view.findViewById(R.id.fbook);
        loginButton.setReadPermissions("public_profile", "email");

        loginButton.setFragment(this);
        if (!TextUtils.isEmpty(SharePrefranceData.getFirstName(mContext)) && !TextUtils.isEmpty(SharePrefranceData.getLastName(mContext)) && !TextUtils.isEmpty(SharePrefranceData.getEmail(mContext))) {
            fName.setText(SharePrefranceData.getFirstName(mContext));
            lName.setText(SharePrefranceData.getLastName(mContext));
            email.setText(SharePrefranceData.getEmail(mContext));
        }

        try {
            callbackManager = CallbackManager.Factory.create();
        } catch (Exception e) {
            e.printStackTrace();
        }
        fbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FBlogin();
            }
        });


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String fname = fName.getText().toString();
                String lname = lName.getText().toString();
                String email1 = email.getText().toString();

                if (fname.equals("")) {
                    alert();
                } else if (lname.equals("")) {
                    alert();
                } else if (email1.equals("")) {
                    alert();
                } else {

                    SharePrefranceData sharePrefranceData = new SharePrefranceData();
                    sharePrefranceData.addUserDetail(mContext, fname, lname, email1);
                }
            }
        });


        callbackManager = CallbackManager.Factory.create();

        LoginManager.getInstance().registerCallback(callbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        GraphRequest request = GraphRequest.newMeRequest(
                                loginResult.getAccessToken(),
                                new GraphRequest.GraphJSONObjectCallback() {

                                    @Override
                                    public void onCompleted(JSONObject object, GraphResponse response) {
                                        Log.v("Main", response.toString());
                                        setProfileToView(object);
                                    }

                                    private void setProfileToView(JSONObject jsonObject) {

                                        try {
                                            email.setText(jsonObject.getString("email"));
                                            fName.setText(jsonObject.getString("name"));
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                });
                        Bundle parameters = new Bundle();
                        parameters.putString("fields", "id,name,email");
                        request.setParameters(parameters);
                        request.executeAsync();
                    }

                    @Override
                    public void onCancel() {
                        // App code
                    }

                    @Override
                    public void onError(FacebookException exception) {
                        Toast.makeText(getActivity(), "error to Login Facebook", Toast.LENGTH_SHORT).show();
                    }
                });

        return view;

    }

    void alert() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(mContext);
        alertDialog.setTitle("Some Field is Empty");
        alertDialog.setMessage("Please fill the Empty Fields");
        alertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();

            }
        });
        alertDialog.show();

    }

    void fbalert() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(mContext);
        alertDialog.setTitle("Facebook Login");
        alertDialog.setMessage("Login done successfully");
        alertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                fName.setText(SharePrefranceData.getFirstName(mContext));
                lName.setText(SharePrefranceData.getLastName(mContext));
                email.setText(SharePrefranceData.getEmail(mContext));

            }
        });
        alertDialog.show();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        callbackManager.onActivityResult(requestCode, resultCode, data);
    }


    public void FBlogin() {
        loginButton.setReadPermissions("public_profile", "email");
        AccessToken token = AccessToken.getCurrentAccessToken();
        if (token == null) {
            loginButton.performClick();
            loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
                @Override
                public void onSuccess(LoginResult loginResult) {
                    handleFacebookAccessToken(loginResult.getAccessToken());
                }

                @Override
                public void onCancel() {

                }

                @Override
                public void onError(FacebookException exception) {
                    Log.e("Error", exception.toString());
                }
            });
        } else {
            handleFacebookAccessToken(token);
        }
    }

    private void handleFacebookAccessToken(final AccessToken token) {
        GraphRequest data_request = GraphRequest.newMeRequest(
                token, new GraphRequest.GraphJSONObjectCallback() {
                    @Override
                    public void onCompleted(JSONObject json_object, GraphResponse response) {
                        JSONObject obj = json_object;
                        try {
                            String name = obj.getString("name");
                            JSONObject data = response.getJSONObject();
                            String profileUrl = data.getJSONObject("picture").getJSONObject("data").getString("url");
                            String email = obj.getString("email");
                            String lastName = "";
                            String firstName= "";
                            if(name.split("\\w+").length>1){

                                lastName = name.substring(name.lastIndexOf(" ")+1);
                                firstName = name.substring(0, name.lastIndexOf(' '));
                            }
                            else{
                                firstName = name;
                            }
                            SharePrefranceData.addUserDetail(mContext,firstName,lastName,email);
                            fbalert();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
        Bundle permission_param = new Bundle();
        permission_param.putString("fields", "id,name,email, picture.width(120).height(120)");
        data_request.setParameters(permission_param);
        data_request.executeAsync();
    }


}