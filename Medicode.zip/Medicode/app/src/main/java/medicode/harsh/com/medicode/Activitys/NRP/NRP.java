package medicode.harsh.com.medicode.Activitys.NRP;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import java.io.ByteArrayOutputStream;

import medicode.harsh.com.medicode.R;

public class NRP extends AppCompatActivity {

   private LinearLayout steps,step1,next,previous,step2;
   RelativeLayout tool;
   com.jsibbold.zoomage.ZoomageView image;
   View view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nrp);
        final ImageView iv_compressed = findViewById(R.id.zoom1);
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.firstimage);

        DisplayMetrics metrics = this.getResources().getDisplayMetrics();
        int imageWidth = 0;
        int imageHeight = 0;
        if (bitmap != null) {
            imageWidth = bitmap.getWidth();
            imageHeight = bitmap.getHeight();
        }

        try {
            bitmap = Bitmap.createScaledBitmap(bitmap, metrics.widthPixels, metrics.heightPixels, true);
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 2;
            iv_compressed.setImageBitmap(bitmap);
        } catch (Exception e) {
            e.printStackTrace();
        }

        steps = view.findViewById(R.id.Steps);
        image = view.findViewById(R.id.zoom1);
        step1 = view.findViewById(R.id.step1);
        tool =  view.findViewById(R.id.tool);
        next = view.findViewById(R.id.next);
        previous= view.findViewById(R.id.previous);

        steps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                image.setVisibility(View.GONE);
                steps.setVisibility(View.GONE);
                tool.setVisibility(View.VISIBLE);
                step1.setVisibility(View.VISIBLE);
                next.setVisibility(View.VISIBLE);
                previous.setVisibility(View.GONE);



            }
        });

        step2=view.findViewById(R.id.step2);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                step1.setVisibility(View.GONE);
                previous.setVisibility(View.VISIBLE);
                step2.setVisibility(View.VISIBLE);
            }
        });

    }


}
