package medicode.harsh.com.medicode.Activitys.PALS;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

import medicode.harsh.com.medicode.Adapters.PALSAdapter;
import medicode.harsh.com.medicode.Models.PALSList;
import medicode.harsh.com.medicode.R;

public class PALS extends AppCompatActivity {

    RecyclerView recyclerView;
    PALSAdapter adapter;
    private ArrayList<PALSList> listContentArr = new ArrayList<PALSList>();
    private Context mContext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pals);
        mContext=this;
        recyclerView=findViewById(R.id.recycleView_PALS);
        LinearLayoutManager linearLayoutManager= new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        adapter= new PALSAdapter(mContext,listContentArr);
        populateRecyclerViewValues();
        recyclerView.setAdapter(adapter);
    }

    private void populateRecyclerViewValues() {
        listContentArr.clear();
        PALSList pals= new PALSList();
        pals.setName("PEDIATRIC CARDIAC ARREST");
        listContentArr.add(pals);
        PALSList pals1 = new PALSList();
        pals1.setName("DETAILS FOR PEDIATRIC CARDIAC ARREST");
        listContentArr.add(pals1);
        PALSList pals2= new PALSList();
        pals2.setName("IMMEDIATE POST FOR CARDIAC ARREST");
        listContentArr.add(pals);
        PALSList pals3= new PALSList();
        pals3.setName("PEDIATRIC BRADYCARDIA WITH PULSE/POOR PERFUSION");
        listContentArr.add(pals3);
        PALSList pals4= new PALSList();
        pals4.setName("PEDIATRIC TACHYCARDIA");
        listContentArr.add(pals4);
        adapter.notifyDataSetChanged();


    }
}
