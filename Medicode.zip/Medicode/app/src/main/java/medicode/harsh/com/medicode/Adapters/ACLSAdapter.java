package medicode.harsh.com.medicode.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import medicode.harsh.com.medicode.Models.ACLSList;
import medicode.harsh.com.medicode.Activitys.ACLS.ACLS_bracardia;
import medicode.harsh.com.medicode.Activitys.ACLS.ACLS_cardiac;
import medicode.harsh.com.medicode.Activitys.ACLS.ACLS_details;
import medicode.harsh.com.medicode.Activitys.ACLS.ACLS_immediate;
import medicode.harsh.com.medicode.Activitys.ACLS.ACLS_tachycardiac;
import medicode.harsh.com.medicode.R;

public class ACLSAdapter extends RecyclerView.Adapter<ACLSAdapter.MyViewHolder> {

    private ArrayList<ACLSList> list_members = new ArrayList<>();
    View view;
    Context adapterContext;

    public ACLSAdapter(Context mContext, ArrayList<ACLSList> listContentArr) {
        this.adapterContext= mContext;
        this.list_members=listContentArr;
    }

    @NonNull
    @Override
    public ACLSAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        view= LayoutInflater.from(parent.getContext()).inflate(R.layout.acls_inside,parent,false);
        return new ACLSAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ACLSAdapter.MyViewHolder holder, final int position) {
        ACLSList list_items = list_members.get(position);
        holder.name.setText(list_items.getName());
        holder.name.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                //Toast.makeText(adapterContext,list_members.get(position).getName(), Toast.LENGTH_SHORT).show();
                if(list_members.get(position).getName()=="CARDIAC ARREST"){
                    Intent intent = new Intent(adapterContext, ACLS_cardiac.class);
                    adapterContext.startActivity(intent);
                }
                else if(list_members.get(position).getName()=="DETAILS FOR CARDIAC ARREST") {
                    Intent intent = new Intent(adapterContext, ACLS_details.class);
                    adapterContext.startActivity(intent);
                }
                else if(list_members.get(position).getName()=="IMMEDIATE POST-CARDIAC ARREST") {
                    Intent intent = new Intent(adapterContext, ACLS_immediate.class);
                    adapterContext.startActivity(intent);
                }
                else if(list_members.get(position).getName()=="BRADYCARDIA WITH PULSE") {
                    Intent intent = new Intent(adapterContext, ACLS_bracardia.class);
                    adapterContext.startActivity(intent);
                }
                else if(list_members.get(position).getName()=="TACHYCARDIA WITH PULSE") {
                    Intent intent = new Intent(adapterContext, ACLS_tachycardiac.class);
                    adapterContext.startActivity(intent);
                }


            }
        });


    }

    public void setListContent(ArrayList<ACLSList> list_members) {
        this.list_members = list_members;
        notifyItemRangeChanged(0, list_members.size());

    }
    @Override
    public int getItemCount() {
        return list_members.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView name;

        public MyViewHolder(View itemView){
            super(itemView);
            itemView.setOnClickListener(this);
            name=itemView.findViewById(R.id.name2);
        }
        @Override
        public void onClick(View v) {
        }

    }

    public void removeAt(int position) {
        list_members.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(0, list_members.size());
    }

}
