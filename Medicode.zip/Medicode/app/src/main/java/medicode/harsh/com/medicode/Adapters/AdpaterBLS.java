package medicode.harsh.com.medicode.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import medicode.harsh.com.medicode.Activitys.BLS.BLS_adult;
import medicode.harsh.com.medicode.Activitys.BLS.BLS_pediatric;
import medicode.harsh.com.medicode.R;
import medicode.harsh.com.medicode.Models.blsList;

public class AdpaterBLS extends RecyclerView.Adapter<AdpaterBLS.MyViewHolder> {

    private ArrayList<blsList> list_members = new ArrayList<>();
    View view;
    Context adapterContext;



    public AdpaterBLS(Context mContext, ArrayList<blsList> listContentArr) {
        this.adapterContext= mContext;
        this.list_members=listContentArr;
    }


    @Override
    public AdpaterBLS.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.bls_inside, parent, false);
        return new AdpaterBLS.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdpaterBLS.MyViewHolder holder, final int position) {
        blsList list_items = list_members.get(position);
        holder.name1.setText(list_items.getName());
        holder.name1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Toast.makeText(adapterContext, list_members.get(position).getName(), Toast.LENGTH_SHORT).show();
                if(list_members.get(position).getName()=="ADULT"){
                    Intent intent = new Intent(adapterContext, BLS_adult.class);
                    adapterContext.startActivity(intent);
                }
                else if(list_members.get(position).getName()=="PEDIATRIC") {
                    Intent intent = new Intent(adapterContext, BLS_pediatric.class);
                    adapterContext.startActivity(intent);
                }

            }
        });
    }


    public void setListContent(ArrayList<blsList> list_members) {
        this.list_members = list_members;
        notifyItemRangeChanged(0, list_members.size());

    }

    @Override
    public int getItemCount() {
        return list_members.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView name1;

        public MyViewHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            name1 = itemView.findViewById(R.id.name1);

        }

        @Override
        public void onClick(View v) {
        }

    }

        public void removeAt(int position) {
            list_members.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(0, list_members.size());
        }
}