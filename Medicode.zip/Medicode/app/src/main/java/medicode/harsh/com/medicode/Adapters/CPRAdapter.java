package medicode.harsh.com.medicode.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import medicode.harsh.com.medicode.Activitys.CPR.CPR_adult;
import medicode.harsh.com.medicode.Activitys.CPR.CPR_simple;
import medicode.harsh.com.medicode.Models.CPRList;
import medicode.harsh.com.medicode.R;

public class CPRAdapter extends RecyclerView.Adapter<CPRAdapter.MyViewHolder> {

    private ArrayList<CPRList> list_members = new ArrayList<>();
    View view;
    Context adapterContext;

    public CPRAdapter(Context mContext, ArrayList<CPRList> listContentArr) {
        this.adapterContext= mContext;
        this.list_members=listContentArr;
    }

    @NonNull
    @Override
    public CPRAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        view= LayoutInflater.from(parent.getContext()).inflate(R.layout.acls_inside,parent,false);
        return new CPRAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        CPRList list_items = list_members.get(position);
        holder.name.setText(list_items.getName());
        holder.name.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                //Toast.makeText(adapterContext,list_members.get(position).getName(), Toast.LENGTH_SHORT).show();
                if(list_members.get(position).getName().equals("ADULT BLS")) {
                    Intent intent = new Intent(adapterContext, CPR_adult.class);
                    adapterContext.startActivity(intent);
                }
                else if(list_members.get(position).getName().equals("SIMPLE ADULT BLS")) {
                    Intent intent = new Intent(adapterContext, CPR_simple.class);
                    adapterContext.startActivity(intent);
                }
            }
        });
    }


    public void setListContent(ArrayList<CPRList> list_members) {
        this.list_members = list_members;
        notifyItemRangeChanged(0, list_members.size());

    }

    @Override
    public int getItemCount() {
        return list_members.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView name;

        public MyViewHolder(View itemView){
            super(itemView);
            itemView.setOnClickListener(this);
            name=itemView.findViewById(R.id.name2);
        }
        @Override
        public void onClick(View v) {
        }

    }

    public void removeAt(int position) {
        list_members.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(0, list_members.size());
    }
}
