package medicode.harsh.com.medicode.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import medicode.harsh.com.medicode.Activitys.PALS.PALS_details;
import medicode.harsh.com.medicode.Activitys.PALS.PALS_immediate;
import medicode.harsh.com.medicode.Activitys.PALS.PALS_pedi1;
import medicode.harsh.com.medicode.Activitys.PALS.PALS_pedi2;
import medicode.harsh.com.medicode.Activitys.PALS.PALS_pedi3;
import medicode.harsh.com.medicode.Models.PALSList;
import medicode.harsh.com.medicode.R;

public class PALSAdapter extends RecyclerView.Adapter<PALSAdapter.MyViewHolder> {

    private ArrayList<PALSList> list_members = new ArrayList<>();
    View view;
    Context adapterContext;

    public PALSAdapter(Context mContext, ArrayList<PALSList> listContentArr) {
        this.adapterContext= mContext;
        this.list_members=listContentArr;
    }

    @NonNull
    @Override
    public PALSAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        view= LayoutInflater.from(parent.getContext()).inflate(R.layout.acls_inside,parent,false);
        return new PALSAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PALSAdapter.MyViewHolder holder, final int position) {
        PALSList list_items = list_members.get(position);
        holder.name.setText(list_items.getName());
        holder.name.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //Toast.makeText(adapterContext,list_members.get(position).getName(), Toast.LENGTH_SHORT).show();

                if(list_members.get(position).getName().equals("PEDIATRIC CARDIAC ARREST")) {
                    Intent intent = new Intent(adapterContext, PALS_pedi1.class);
                    adapterContext.startActivity(intent);
                }
                else if(list_members.get(position).getName().equals("DETAILS FOR PEDIATRIC CARDIAC ARREST")) {
                    Intent intent = new Intent(adapterContext, PALS_details.class);
                    adapterContext.startActivity(intent);
                }
                else if(list_members.get(position).getName().equals("IMMEDIATE POST FOR CARDIAC ARREST")) {
                    Intent intent = new Intent(adapterContext, PALS_immediate.class);
                    adapterContext.startActivity(intent);
                }
                else if(list_members.get(position).getName().equals("PEDIATRIC BRADYCARDIA WITH PULSE/POOR PERFUSION")) {
                    Intent intent = new Intent(adapterContext, PALS_pedi2.class);
                    adapterContext.startActivity(intent);
                }
                else if(list_members.get(position).getName().equals("PEDIATRIC TACHYCARDIA")) {
                    Intent intent = new Intent(adapterContext, PALS_pedi3.class);
                    adapterContext.startActivity(intent);
                }

            }
        });
    }


    public void setListContent(ArrayList<PALSList> list_members) {
        this.list_members = list_members;
        notifyItemRangeChanged(0, list_members.size());
    }

    @Override
    public int getItemCount() {
        return list_members.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView name;

        public MyViewHolder(View itemView){
            super(itemView);
            itemView.setOnClickListener(this);
            name=itemView.findViewById(R.id.name2);
        }
        @Override
        public void onClick(View v) {
        }

    }

    public void removeAt(int position) {
        list_members.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(0, list_members.size());
    }
}
