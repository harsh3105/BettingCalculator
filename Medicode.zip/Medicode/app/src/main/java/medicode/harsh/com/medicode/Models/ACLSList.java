package medicode.harsh.com.medicode.Models;

import java.util.ArrayList;

public class ACLSList {
    private String name;
    private ArrayList<algoName> aclslist =new ArrayList<>();

    public ACLSList() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
