package medicode.harsh.com.medicode.Models;

import java.util.ArrayList;

import medicode.harsh.com.medicode.Models.algoName;

public class CPRList {
    private String name;
    private ArrayList<algoName> CPRList =new ArrayList<>();

    public CPRList() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
