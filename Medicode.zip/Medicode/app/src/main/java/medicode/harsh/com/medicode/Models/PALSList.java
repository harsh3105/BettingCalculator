package medicode.harsh.com.medicode.Models;

import java.util.ArrayList;

import medicode.harsh.com.medicode.Models.algoName;

public class PALSList {

    private String name;
    private ArrayList<algoName> PALSList = new ArrayList<>();

    public PALSList() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
