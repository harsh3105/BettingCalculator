package medicode.harsh.com.medicode.Models;

import java.util.ArrayList;

public class algoName {
    private String name;
    private ArrayList<algoName> algoName =new ArrayList<>();

    public algoName()
    {

    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
