package medicode.harsh.com.medicode.Models;

import java.util.ArrayList;

import medicode.harsh.com.medicode.Models.algoName;

public class blsList {
    private String name;
    private ArrayList<algoName> blsList =new ArrayList<>();

    public blsList()
    {

    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
